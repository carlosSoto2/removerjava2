# Uninstall all Java JRE and JDKs (risky if other potentially related (Oracle/Sun) items):
# One line TL;DR version

gwmi Win32_Product -filter "name like 'Java%' AND (vendor like 'Oracle%' OR vendor like 'Sun%')" | % { if (Get-Member -In $_ -Name "Uninstall" -Mem Method) { Write-Host "Uninstalling $($_.Name)"; $_.Uninstall().ReturnValue; } }

# Alternative WMI queries:

# Uninstall Java 7 and 8
gwmi Win32_Product -filter "name like 'Java%' AND vendor like 'Oracle%' AND (version like '[78].%' OR version like '1.[78].%')"

# Uninstall Java 7 only:
gwmi Win32_Product -filter "name like 'Java%' AND vendor like 'Oracle%' AND (version like '7.%' OR version like '1.7.%')"

# Uninstall Java 8 only:
gwmi Win32_Product -filter "name like 'Java%' AND vendor like 'Oracle%' AND (version like '8.%' OR version like '1.8.%')"

# Delete plugins registered with Mozilla applications after installing Java (alternatively, use WEB_JAVA=0 in install to prevent this from happening in the first place)
Remove-Item -Recurse HKLM:\SOFTWARE\MozillaPlugins\@java*
Remove-Item -Recurse HKLM:\SOFTWARE\Wow6432Node\MozillaPlugins\@java*
